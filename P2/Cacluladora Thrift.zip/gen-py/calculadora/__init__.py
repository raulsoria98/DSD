__all__ = ['ttypes', 'constants', 'Calculadora']
